# Calcolare e stampare tutte le potenze di 2 minori di 25000

n = 2
indice = 1

while n ** indice < 25000:
    print(n ** indice)
    indice += 1