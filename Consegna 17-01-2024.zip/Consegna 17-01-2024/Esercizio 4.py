# Calcolare e stampare tutte le prime N potenze di 2 utilizzando un ciclo while, domandando all'utente di inserire N

numero = 2
indice = 1
N = int(input("Inserisci un numero:"))

while indice <= N:
    print(numero ** indice)
    indice +=1