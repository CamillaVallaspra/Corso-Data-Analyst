# Memorizza e stampa tutti i divisori di un numero dato in input.

n = int(input("Inserisci un numero:"))
i = 1
divisori = []

while i <= n: 
    if n % i == 0:
        divisori.append(i)
    i += 1

print(divisori)
        
    
