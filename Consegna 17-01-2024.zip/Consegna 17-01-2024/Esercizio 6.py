# Abbiamo due liste, una di studenti e una di corsi:

studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]

'''
Aggiungere i dati mancanti alla lista corsi, sapendo che
Emma segue Data Analyst 
Faith segue Backend 
Grace segue Frontend 
Henry segue Cybersecurity

Aggiungeremo i dati mancanti uno alla volta con il metodo per appendere in coda alle liste, 
poi verificheremo che sono della stessa lunghezza e se lo sono stamperemo la lista corsi. 
Se alcuni dati sono già presenti non vanno aggiunti di nuovo.
'''
corsi.append("Frontend")
corsi.append("Cybersecurity")

if len(studenti) == len(corsi):
    print(corsi)
else:
    print("Le lunghezze non corrispondono")
