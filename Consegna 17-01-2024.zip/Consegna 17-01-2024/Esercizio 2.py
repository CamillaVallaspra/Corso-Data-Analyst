n = 0
while n <= 20:
    print (n)
    n +=1
