# Scriviamo un programma che chiede in input all'utente una stringa e visualizza i primi 3 caratteri, seguiti da 3 punti di sospensione e quindi gli ultimi 3 caratteri 
# (Stavolta facciamo attenzione a tutti i casi particolari, ovvero implementare soluzioni ad hoc per stringhe di lunghezza inferiore a 6 caratteri)

richiesta = input("Scrivi una stringa:")

if len(richiesta) >= 6:
    print(richiesta[0:3] + "..." + richiesta[-3:])
elif len(richiesta) == 5:
    print(richiesta[0:3] + "..." + richiesta[-2:])
elif len(richiesta) == 4:
    print(richiesta[0:2] + "..." + richiesta[-2:])
elif len(richiesta) == 3:
    print(richiesta[0:2] + "..." + richiesta[-1:])
elif len(richiesta) == 2:
    print(richiesta[0:1] + "..." + richiesta[-1:])
else: 
    print("La stringa è troppo corta...")


