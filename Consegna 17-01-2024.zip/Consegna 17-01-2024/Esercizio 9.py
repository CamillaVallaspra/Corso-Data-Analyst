# Calcolare (ma non stampare) le prime N potenze di K; ognuna di esse andrà memorizzata in coda a una lista. 
# Alla fine, stampare la lista risultante. Proviamo con diversi valori di K, oppure facciamola inserire all'utente.

k = int(input("Inserisci numero intero:"))
n = 1
lista = list()

while n <= 5:
    lista.append(k ** n)
    n += 1

print(lista)
