# Abbiamo una lista di studenti: 

studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry", "Isabelle", "John"] 

# vogliamo dividere gli studenti in due squadre per un campionato di Uno nel seguente modo: 
# selezioneremo i nomi in posizione pari per un squadra, e i nomi in posizione dispari per l'altra. 
# Creiamo due liste per ogni squadra, e alla fine visualizziamole.

sq1=[]
sq2=[]
indice = 0
while indice < len(studenti):
    if indice % 2 == 0:
        sq1.append(studenti[indice])
    else:
        sq2.append(studenti[indice])
    indice +=1 

print(sq1)
print(sq2)



