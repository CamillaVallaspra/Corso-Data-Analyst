# Stampare ogni carattere della stringa, uno su ogni riga, utilizzando un costrutto while.

nome_scuola = "Epicode"
indice = 0

while indice < len(nome_scuola):
    print(nome_scuola[indice])
    indice += 1


