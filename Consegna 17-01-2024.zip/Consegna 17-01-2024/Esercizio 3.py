# Calcolare e stampare tutte le prime 10 potenze di 2 (e.g., 2⁰, 2¹, 2², …) utilizzando un ciclo while

n = 2
indice = 1

while indice <= 10:
    print(n ** indice)
    indice +=1